#include "../JuceLibraryCode/JuceHeader.h"

#include "ntRev3.h"
#include "ntRev3_types.h"

struct onParamChangeListener : AudioProcessorValueTreeState::Listener
{
    onParamChangeListener(ntRev3StackData* sd)
    : SD(sd)
    {
    }
    
    void parameterChanged (const String& parameterID, float newValue) override
    {
	    (void)parameterID;
	    int idx = -1;
        if (parameterID == "t60") {
            idx = 0;
        } else if (parameterID == "tPre") {
            idx = 1;
        } else if (parameterID == "tLateDel") {
            idx = 2;
        } else if (parameterID == "fLpf1") {
            idx = 3;
        } else if (parameterID == "damp") {
            idx = 4;
        } else if (parameterID == "gDriveIn_gui") {
            idx = 5;
        } else if (parameterID == "gEarly_dB") {
            idx = 6;
        } else if (parameterID == "gDiff_dB") {
            idx = 7;
        } else if (parameterID == "mix_gui") {
            idx = 8;
        } else if (parameterID == "modFreq") {
            idx = 9;
        } else if (parameterID == "modDepth_gui") {
            idx = 10;
        } else if (parameterID == "t_early_min") {
            idx = 11;
        } else if (parameterID == "t_early_max") {
            idx = 12;
        } else if (parameterID == "t_late_min") {
            idx = 13;
        } else if (parameterID == "t_late_max") {
            idx = 14;
        } else if (parameterID == "bypass") {
            idx = 15;
        }
		onParamChangeCImpl(SD, idx, static_cast<double>(newValue));
    }

    ntRev3StackData *SD;
};

//==============================================================================
class ntRev3AudioProcessor  : public AudioProcessor
{
public:
    //==============================================================================
    ntRev3AudioProcessor()
    :   paramListener(&mStackData), parameters (*this, nullptr)
    {
        mStackData.pd = &mPersistentData;
        
        ntRev3_initialize(&mStackData);

        createPluginInstance(&mStackData, reinterpret_cast<unsigned long long>(this));

        //
        // Parameter property t60
        //
        parameters.createAndAddParameter ("t60", "Reverb Time", "s",
            NormalisableRange<float>(0.1f, 4.f), 1.4f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("t60", &paramListener);

        //
        // Parameter property tPre
        //
        parameters.createAndAddParameter ("tPre", "Early Delay", "ms",
            NormalisableRange<float>(0.f, 200.f), 25.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("tPre", &paramListener);

        //
        // Parameter property tLateDel
        //
        parameters.createAndAddParameter ("tLateDel", "Late Delay", "ms",
            NormalisableRange<float>(0.f, 200.f), 50.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("tLateDel", &paramListener);

        //
        // Parameter property fLpf1
        //
        parameters.createAndAddParameter ("fLpf1", "Damping Freq", "Hz",
            NormalisableRange<float>(20.f, 20000.f, 
                [](float min, float max, float norm) {return min * powf(max/min, norm);},
                [](float min, float max, float val) {return logf(val/min)/logf(max/min);} ),
            6000.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("fLpf1", &paramListener);

        //
        // Parameter property damp
        //
        parameters.createAndAddParameter ("damp", "Damping Amount", "x",
            NormalisableRange<float>(0.f, 1.f), 0.13f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("damp", &paramListener);

        //
        // Parameter property gDriveIn_gui
        //
        parameters.createAndAddParameter ("gDriveIn_gui", "Input Drive", "dB",
            NormalisableRange<float>(-20.f, 20.f), 8.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("gDriveIn_gui", &paramListener);

        //
        // Parameter property gEarly_dB
        //
        parameters.createAndAddParameter ("gEarly_dB", "Early Reflections", "dB",
            NormalisableRange<float>(-100.f, 0.f), -10.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("gEarly_dB", &paramListener);

        //
        // Parameter property gDiff_dB
        //
        parameters.createAndAddParameter ("gDiff_dB", "Reverb Tail", "dB",
            NormalisableRange<float>(-100.f, 0.f), 0.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("gDiff_dB", &paramListener);

        //
        // Parameter property mix_gui
        //
        parameters.createAndAddParameter ("mix_gui", "Mix", "%",
            NormalisableRange<float>(0.f, 100.f), 30.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("mix_gui", &paramListener);

        //
        // Parameter property modFreq
        //
        parameters.createAndAddParameter ("modFreq", "Mod freq", "Hz",
            NormalisableRange<float>(0.1f, 10.f, 
                [](float min, float max, float norm) {return min * powf(max/min, norm);},
                [](float min, float max, float val) {return logf(val/min)/logf(max/min);} ),
            4.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("modFreq", &paramListener);

        //
        // Parameter property modDepth_gui
        //
        parameters.createAndAddParameter ("modDepth_gui", "Mod Depth", "%",
            NormalisableRange<float>(0.01f, 100.f, 
                [](float min, float max, float norm) {return min * powf(max/min, norm);},
                [](float min, float max, float val) {return logf(val/min)/logf(max/min);} ),
            2.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("modDepth_gui", &paramListener);

        //
        // Parameter property t_early_min
        //
        parameters.createAndAddParameter ("t_early_min", "Early first", "ms",
            NormalisableRange<float>(1.f, 20.f, 1.f), 5.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("t_early_min", &paramListener);

        //
        // Parameter property t_early_max
        //
        parameters.createAndAddParameter ("t_early_max", "Early last", "ms",
            NormalisableRange<float>(20.f, 100.f, 1.f), 100.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("t_early_max", &paramListener);

        //
        // Parameter property t_late_min
        //
        parameters.createAndAddParameter ("t_late_min", "Late First", "ms",
            NormalisableRange<float>(1.f, 20.f, 1.f), 5.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("t_late_min", &paramListener);

        //
        // Parameter property t_late_max
        //
        parameters.createAndAddParameter ("t_late_max", "Late Last", "ms",
            NormalisableRange<float>(20.f, 200.f, 1.f), 100.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("t_late_max", &paramListener);

        //
        // Parameter property bypass
        //
        const StringArray choices16({ "In", "Out" });
        parameters.createAndAddParameter ("bypass", "Master Bypass", "",
            NormalisableRange<float>(0.f, choices16.size()-1.f, 1.f), 0.f,
            [=](float value) { return choices16[(int) (value + 0.5)]; },
            [=](const String& text) { return (float) choices16.indexOf(text); },
            false, true, true);
        parameters.addParameterListener("bypass", &paramListener);

        parameters.state = ValueTree(Identifier("ntRev3"));
    }

    ~ntRev3AudioProcessor()
    {
        ntRev3_terminate();
    }
    
    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override
    {
        (void)samplesPerBlock;
        resetCImpl(&mStackData, sampleRate);
        setLatencySamples(getLatencyInSamplesCImpl(&mStackData));
    }

    void releaseResources() override                { }
    
    
    void processBlock (AudioBuffer<double>& buffer, MidiBuffer& midiMessages) override
    {
        (void)midiMessages;
        ScopedNoDenormals noDenormals;
        const double** inputs = buffer.getArrayOfReadPointers();
        double** outputs = buffer.getArrayOfWritePointers();
        int nSamples = buffer.getNumSamples();
        ntRev3StackData *SD = &mStackData;

        int osz0_;
        int osz1_;
        if (nSamples <= MAX_SAMPLES_PER_FRAME) {
            /* Fast path for common frame sizes. */
            int isz0_ = nSamples;
            int isz1_ = nSamples;
            processEntryPoint(SD, (double)nSamples,
                    inputs[0], &isz0_,
                    inputs[1], &isz1_,
                    outputs[0], &osz0_,
                    outputs[1], &osz1_);
        } else {
            /* Fallback for unusually large frames. */
            int isz0_ = MAX_SAMPLES_PER_FRAME;
            int isz1_ = MAX_SAMPLES_PER_FRAME;
            int n = MAX_SAMPLES_PER_FRAME;
            for (int i_ = 0; i_ < nSamples; i_ += MAX_SAMPLES_PER_FRAME) {
                if (i_ + MAX_SAMPLES_PER_FRAME > nSamples) {
                    n = nSamples - i_;
                    isz0_ = nSamples - i_;
                    isz1_ = nSamples - i_;
                }
                processEntryPoint(SD, (double)n,
                        inputs[0]+i_, &isz0_,
                        inputs[1]+i_, &isz1_,
                        outputs[0]+i_, &osz0_,
                        outputs[1]+i_, &osz1_);
            }
        }

    }
    
    void processBlock (AudioBuffer<float>& buffer,  MidiBuffer& midiMessages) override
    {
        (void)midiMessages;
        AudioBuffer<double> doubleBuffer;
        doubleBuffer.makeCopyOf(buffer);
        processBlock(doubleBuffer, midiMessages);
        buffer.makeCopyOf(doubleBuffer);
    }
    
    //==============================================================================
    bool hasEditor() const override                 { return true; }
    AudioProcessorEditor* createEditor() override;
    
    //==============================================================================
    const String getName() const override           { return JucePlugin_Name; }

    bool acceptsMidi() const override               { return false; }
    bool producesMidi() const override              { return false; }
    bool isMidiEffect () const override             { return false; }
    double getTailLengthSeconds() const override    { return 0.0;   }

    //==============================================================================
    // NB: some hosts don't cope very well if you tell them there are 0 programs,
    // so this should be at least 1, even if you're not really implementing programs.
    int getNumPrograms() override                       { return 1;  }
    int getCurrentProgram() override                    { return 0;  }
    void setCurrentProgram (int index) override         { (void) index; }
    const String getProgramName (int index) override    { (void) index; return {}; }
    void changeProgramName (int index, const String& newName) override  { (void) index; (void) newName; }
    
    //==============================================================================
    void getStateInformation (MemoryBlock& destData) override
    {
        ScopedPointer<XmlElement> xml (parameters.state.createXml());
        copyXmlToBinary (*xml, destData);
    }
    
    void setStateInformation (const void* data, int sizeInBytes) override
    {
        ScopedPointer<XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
        if (xmlState != nullptr)
            if (xmlState->hasTagName (parameters.state.getType()))
                parameters.state = ValueTree::fromXml (*xmlState);
    }
    
    bool supportsDoublePrecisionProcessing() const override  { return true; }
    
private:
    //==============================================================================
    static const int MAX_SAMPLES_PER_FRAME = 4096;

    ntRev3StackData mStackData;
    ntRev3PersistentData mPersistentData;
    onParamChangeListener paramListener;
    
    //==============================================================================
    AudioProcessorValueTreeState parameters;
 
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ntRev3AudioProcessor)
};

//==============================================================================
// This creates new instances of the plugin..
AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ntRev3AudioProcessor();
}

#include "ntRev3PluginEditor.h"

AudioProcessorEditor* ntRev3AudioProcessor::createEditor()
{
    return new ntRev3AudioProcessorEditor(*this, parameters);
}

