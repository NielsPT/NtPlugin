//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  ntRev3.cpp
//
//  Code generation for function 'ntRev3'
//


// Include files
#include "ntRev3.h"
#include "ntRev3_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "rt_nonfinite.h"
#include <cfloat>
#include <cmath>
#include <cstring>

// Function Declarations
static void b_primesInRange(coder::array<double, 2U> &prim);
static void c_primesInRange(coder::array<double, 2U> &prim);
namespace coder
{
  static unsigned int intsqrt(unsigned int a);
  static int intsqrt(int a);
  static boolean_T isprime(double X);
  static void primes(double n, ::coder::array<double, 2U> &p);
}

static void d_primesInRange(coder::array<double, 2U> &prim);
static int div_s32_floor(int numerator, int denominator);
static derivedAudioPlugin *getPluginInstance(ntRev3StackData *SD);
static void getPluginInstance_init(ntRev3StackData *SD);
static void primesInRange(double b_min, double b_max, coder::array<double, 2U>
  &prim);
static void primesInRange(coder::array<double, 2U> &prim);
static double rt_powd_snf(double u0, double u1);
static double rt_remd_snf(double u0, double u1);
static double rt_roundd_snf(double u);

// Function Definitions
int derivedAudioPlugin::getLatencyInSamplesInt32() const
{
  return this->PrivateLatency;
}

double derivedAudioPlugin::getSampleRate() const
{
  return this->PrivateSampleRate;
}

derivedAudioPlugin *derivedAudioPlugin::init(ntRev3StackData *SD)
{
  static const double dv[16] = { 1.0, 1.02, 0.818, 0.635, 0.719, 0.267, 0.242,
    0.2, 1.0, 1.02, 0.818, 0.635, 0.719, 0.267, 0.242, 0.2 };

  static const signed char iv[64] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1, -1, 1,
    -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, -1, 1, -1, -1, 1, 1, -1, -1, 1, 1, 1, 1,
    1, -1, -1, -1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, -1, -1, -1, 1, 1, 1,
    -1, -1, 1, -1, 1, 1, -1 };

  derivedAudioPlugin *plugin;
  int i;
  plugin = this;

  //  Pass constructor args to plugin.
  plugin->fs = 48000.0;
  plugin->tPre = 25.0;
  plugin->nPre = 0.0;
  plugin->t60 = 1.4;
  plugin->mix_gui = 30.0;
  plugin->gEarly_dB = -10.0;
  plugin->gDiff_dB = 0.0;
  plugin->fLpf1 = 6000.0;
  plugin->damp = 0.13;
  plugin->tLateDel = 50.0;
  plugin->mix = 1.0;
  plugin->serial = false;
  plugin->bypass = false;
  plugin->method = 6.0;
  plugin->t_early_min = 5.0;
  plugin->t_early_max = 100.0;
  plugin->t_late_min = 5.0;
  plugin->t_late_max = 100.0;
  plugin->modFreq = 4.0;
  for (i = 0; i < 16; i++) {
    plugin->modPhase[i] = 0.0;
  }

  plugin->modDepth_gui = 2.0;
  plugin->modDepth = 0.01;
  plugin->gDriveIn_gui = 8.0;
  plugin->gDriveOut_gui = 0.0;
  plugin->gDriveIn = 1.0;
  for (i = 0; i < 307200; i++) {
    plugin->dLineEarly[i] = 0.0;
  }

  for (i = 0; i < 1228800; i++) {
    plugin->dLineLate[i] = 0.0;
  }

  for (i = 0; i < 153600; i++) {
    plugin->dLineLateDel[i] = 0.0;
  }

  for (i = 0; i < 16; i++) {
    plugin->nEarly[i] = 0.0;
  }

  for (i = 0; i < 16; i++) {
    plugin->nLate[i] = 0.0;
  }

  plugin->nLateDel = 1.0;
  for (i = 0; i < 16; i++) {
    plugin->gEarly[i] = dv[i];
  }

  plugin->stLocLate = 1.0;
  plugin->stLocEarly = 1.0;
  for (i = 0; i < 16; i++) {
    plugin->gLate[i] = 0.0;
  }

  for (i = 0; i < 64; i++) {
    plugin->Q[i] = iv[i];
  }

  for (i = 0; i < 8; i++) {
    plugin->inGain[i] = 0.5;
  }

  for (i = 0; i < 8; i++) {
    plugin->outGain[i] = 1.0;
  }

  for (i = 0; i < 16; i++) {
    plugin->stLpf1[i] = 0.0;
  }

  plugin->aLpf1 = 0.0;
  plugin->aEarly = 0.0;
  plugin->aLate = 0.0;
  plugin->infTime = 0.0;
  plugin->PrivateLatency = 0;
  if (!SD->pd->thisPtr_not_empty) {
    SD->pd->thisPtr = 0UL;
    SD->pd->thisPtr_not_empty = true;
  }

  return plugin;
}

void derivedAudioPlugin::initDelay()
{
  coder::array<double, 2U> t;
  double b_n;
  double n;
  int i;
  int k;
  int nx;
  if (this->method == 1.0) {
    coder::primes(this->fs, t);
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * 0.1;
    }

    if (1 > t.size(1)) {
      i = 1;
    } else {
      i = 16;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k] = rt_roundd_snf(t[i * (k + 1)] * n / 1000.0);
    }

    if (2 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 1;
      nx = 16;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k + 8] = rt_roundd_snf(t[i + nx * (k + 1)] * n / 1000.0);
    }

    if (3 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 2;
      nx = 16;
    }

    n = this->fs;
    b_n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nEarly[k] = rt_roundd_snf(t[i + nx * (k + 3)] * n / 1000.0);
      this->nEarly[k + 8] = rt_roundd_snf(t[i + nx * (k + 2)] * b_n / 1000.0);
    }
  }

  if (this->method == 2.0) {
    coder::primes(this->fs, t);
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * 0.2;
    }

    if (1 > t.size(1)) {
      i = 1;
    } else {
      i = 8;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k] = rt_roundd_snf(t[i * (k + 1)] * n / 1000.0);
    }

    if (2 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 1;
      nx = 8;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k + 8] = rt_roundd_snf(t[i + nx * (k + 1)] * n / 1000.0);
    }

    if (3 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 2;
      nx = 8;
    }

    n = this->fs;
    b_n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nEarly[k] = rt_roundd_snf(t[i + nx * (k + 3)] * n / 1000.0);
      this->nEarly[k + 8] = rt_roundd_snf(t[i + nx * (k + 2)] * b_n / 1000.0);
    }
  }

  if (this->method == 3.0) {
    coder::primes(this->fs, t);
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * 0.3;
    }

    if (1 > t.size(1)) {
      i = 1;
    } else {
      i = 8;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k] = rt_roundd_snf(t[i * (k + 1)] * n / 1000.0);
    }

    if (2 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 1;
      nx = 8;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k + 8] = rt_roundd_snf(t[i + nx * (k + 1)] * n / 1000.0);
    }

    if (3 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 2;
      nx = 8;
    }

    n = this->fs;
    b_n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nEarly[k] = rt_roundd_snf(t[i + nx * (k + 3)] * n / 1000.0);
      this->nEarly[k + 8] = rt_roundd_snf(t[i + nx * (k + 2)] * b_n / 1000.0);
    }
  }

  if (this->method == 4.0) {
    coder::primes(this->fs, t);
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * 0.5;
    }

    if (1 > t.size(1)) {
      i = 1;
    } else {
      i = 4;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k] = rt_roundd_snf(t[i * (k + 1)] * n / 1000.0);
    }

    if (2 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 1;
      nx = 4;
    }

    n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nLate[k + 8] = rt_roundd_snf(t[i + nx * (k + 1)] * n / 1000.0);
    }

    if (3 > t.size(1)) {
      i = 0;
      nx = 1;
    } else {
      i = 2;
      nx = 4;
    }

    n = this->fs;
    b_n = this->fs;
    for (k = 0; k < 8; k++) {
      this->nEarly[k] = rt_roundd_snf(t[i + nx * (k + 3)] * n / 1000.0);
      this->nEarly[k + 8] = rt_roundd_snf(t[i + nx * (k + 2)] * b_n / 1000.0);
    }
  }

  if (this->method == 5.0) {
    primesInRange(t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nLate[i] = t[i];
    }

    b_primesInRange(t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nLate[i + 8] = t[i];
    }

    c_primesInRange(t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nEarly[i] = t[i];
    }

    d_primesInRange(t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nEarly[i + 8] = t[i];
    }
  }

  if (this->method == 6.0) {
    n = this->t_late_min;
    do {
      n++;
    } while (!coder::isprime(n));

    b_n = this->t_late_max;
    do {
      b_n++;
    } while (!coder::isprime(b_n));

    primesInRange(n, b_n, t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nLate[i] = t[i];
    }

    n = this->t_late_min;
    do {
      n++;
    } while (!coder::isprime(n));

    do {
      n++;
    } while (!coder::isprime(n));

    b_n = this->t_late_max;
    do {
      b_n++;
    } while (!coder::isprime(b_n));

    do {
      b_n++;
    } while (!coder::isprime(b_n));

    primesInRange(n, b_n, t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nLate[i + 8] = t[i];
    }

    n = this->t_early_min;
    do {
      n++;
    } while (!coder::isprime(n));

    b_n = this->t_early_max;
    do {
      b_n++;
    } while (!coder::isprime(b_n));

    primesInRange(n, b_n, t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nEarly[i] = t[i];
    }

    n = this->t_early_min;
    do {
      n++;
    } while (!coder::isprime(n));

    do {
      n++;
    } while (!coder::isprime(n));

    b_n = this->t_early_max;
    do {
      b_n++;
    } while (!coder::isprime(b_n));

    do {
      b_n++;
    } while (!coder::isprime(b_n));

    primesInRange(n, b_n, t);
    n = this->fs;
    i = t.size(0) * t.size(1);
    t.set_size(1, t.size(1));
    nx = i - 1;
    for (i = 0; i <= nx; i++) {
      t[i] = t[i] * n / 1000.0;
    }

    nx = t.size(1);
    for (k = 0; k < nx; k++) {
      t[k] = rt_roundd_snf(t[k]);
    }

    for (i = 0; i < 8; i++) {
      this->nEarly[i + 8] = t[i];
    }
  }

  //  disp("late min " + num2str(min(p.nLate) / p.fs * 1000) + "ms")
  //  disp("late max " + num2str(max(p.nLate) / p.fs * 1000) + "ms")
  //  disp("early min " + num2str(min(p.nEarly) / p.fs * 1000) + "ms")
  //  disp("early max " + num2str(max(p.nEarly) / p.fs * 1000) + "ms")
}

void derivedAudioPlugin::process(coder::array<double, 2U> &x, coder::array<
  double, 2U> &y)
{
  double nMod[16];
  double dv[1];
  double accum_idx_0;
  double accum_idx_1;
  double yClipperIn_idx_0;
  double yEarly_idx_0;
  double yEarly_idx_1;
  double yLate_idx_0;
  double yLate_idx_1;
  int i;
  int n;
  int tmp_size_idx_0;
  int trueCount;
  int u0;
  short b_tmp_data[8192];
  boolean_T tmp_data[8192];
  u0 = x.size(0);
  if (u0 <= 2) {
    u0 = 2;
  }

  if (x.size(0) == 0) {
    n = 0;
  } else {
    n = u0;
  }

  u0 = x.size(0);
  if (u0 <= 2) {
    u0 = 2;
  }

  if (x.size(0) == 0) {
    u0 = 0;
  }

  y.set_size(u0, 2);
  u0 <<= 1;
  for (trueCount = 0; trueCount < u0; trueCount++) {
    y[trueCount] = 0.0;
  }

  tmp_size_idx_0 = x.size(0);
  u0 = x.size(0) * x.size(1);
  for (trueCount = 0; trueCount < u0; trueCount++) {
    tmp_data[trueCount] = rtIsNaN(x[trueCount]);
  }

  u0 = (tmp_size_idx_0 << 1) - 1;
  trueCount = 0;
  tmp_size_idx_0 = 0;
  for (i = 0; i <= u0; i++) {
    if (tmp_data[i]) {
      trueCount++;
      b_tmp_data[tmp_size_idx_0] = static_cast<short>(i + 1);
      tmp_size_idx_0++;
    }
  }

  u0 = trueCount - 1;
  for (trueCount = 0; trueCount <= u0; trueCount++) {
    x[b_tmp_data[trueCount] - 1] = 0.0;
  }

  for (i = 0; i < n; i++) {
    if (this->bypass) {
      y[i] = x[i];
      y[i + y.size(0)] = x[i + x.size(0)];
    } else {
      double b;
      double b_b;
      double loc;
      double yClipperIn_idx_1;
      yClipperIn_idx_0 = x[i] * this->gDriveIn;
      yClipperIn_idx_1 = x[i + x.size(0)] * this->gDriveIn;
      if (yClipperIn_idx_0 > 1.0) {
        yClipperIn_idx_0 = 1.0;
      } else if (yClipperIn_idx_0 < -1.0) {
        yClipperIn_idx_0 = -1.0;
      } else {
        yClipperIn_idx_0 = (1.5 * yClipperIn_idx_0 - 0.5 * rt_powd_snf
                            (yClipperIn_idx_0, 3.0)) / 1.5;
      }

      if (yClipperIn_idx_1 > 1.0) {
        yClipperIn_idx_1 = 1.0;
      } else if (yClipperIn_idx_1 < -1.0) {
        yClipperIn_idx_1 = -1.0;
      } else {
        yClipperIn_idx_1 = (1.5 * yClipperIn_idx_1 - 0.5 * rt_powd_snf
                            (yClipperIn_idx_1, 3.0)) / 1.5;
      }

      u0 = static_cast<int>(this->stLocEarly);
      loc = yClipperIn_idx_0 / this->gDriveIn;
      yClipperIn_idx_0 = loc;
      this->dLineEarly[u0 - 1] = loc;
      yEarly_idx_0 = 0.0;
      loc = yClipperIn_idx_1 / this->gDriveIn;
      yClipperIn_idx_1 = loc;
      this->dLineEarly[u0 + 153599] = loc;
      yEarly_idx_1 = 0.0;
      for (tmp_size_idx_0 = 0; tmp_size_idx_0 < 8; tmp_size_idx_0++) {
        loc = (this->stLocEarly - this->nEarly[tmp_size_idx_0]) - this->nPre;
        dv[0] = loc;
        trueCount = 0;
        if (loc < 1.0) {
          trueCount = 1;
        }

        if (0 <= trueCount - 1) {
          dv[0] = loc + 153600.0;
        }

        yEarly_idx_1 += this->dLineEarly[static_cast<int>(dv[0]) + 153599] *
          this->gEarly[tmp_size_idx_0 + 8];
        loc = (this->stLocEarly - this->nEarly[tmp_size_idx_0 + 8]) - this->nPre;
        dv[0] = loc;
        trueCount = 0;
        if (loc < 1.0) {
          trueCount = 1;
        }

        if (0 <= trueCount - 1) {
          dv[0] = loc + 153600.0;
        }

        yEarly_idx_0 += this->dLineEarly[static_cast<int>(dv[0]) - 1] *
          this->gEarly[tmp_size_idx_0];
      }

      if (this->serial) {
        yClipperIn_idx_0 = yEarly_idx_0;
        yClipperIn_idx_1 = yEarly_idx_1;
      }

      yLate_idx_0 = 0.0;
      yLate_idx_1 = 0.0;
      this->infTime++;
      loc = 6.2831853071795862 * this->modFreq / this->fs * this->infTime;
      for (u0 = 0; u0 < 16; u0++) {
        nMod[u0] = rt_roundd_snf(std::sin(loc + this->modPhase[u0] *
          3.1415926535897931 / 180.0) * this->nLate[u0] * this->modDepth);
      }

      for (tmp_size_idx_0 = 0; tmp_size_idx_0 < 8; tmp_size_idx_0++) {
        double accum_idx_0_tmp;
        accum_idx_0 = 0.0;
        accum_idx_1 = 0.0;
        for (u0 = 0; u0 < 8; u0++) {
          loc = (this->stLocLate - this->nLate[u0]) - nMod[u0];
          dv[0] = loc;
          trueCount = 0;
          if (loc < 1.0) {
            trueCount = 1;
          }

          if (0 <= trueCount - 1) {
            dv[0] = loc + 76800.0;
          }

          accum_idx_0_tmp = this->Q[tmp_size_idx_0 + (u0 << 3)];
          accum_idx_0 += this->dLineLate[(static_cast<int>(dv[0]) + 153600 * u0)
            - 1] * accum_idx_0_tmp;
          loc = (this->stLocLate - this->nLate[u0 + 8]) - nMod[u0];
          dv[0] = loc;
          trueCount = 0;
          if (loc < 1.0) {
            trueCount = 1;
          }

          if (0 <= trueCount - 1) {
            dv[0] = loc + 76800.0;
          }

          accum_idx_1 += this->dLineLate[(static_cast<int>(dv[0]) + 153600 * u0)
            + 76799] * accum_idx_0_tmp;

          //  TODO: diffusion
        }

        double a;
        double b_a;
        double p;
        p = this->inGain[tmp_size_idx_0];
        a = this->aLpf1;
        b_a = 1.0 - this->aLpf1;
        b = this->damp;
        b_b = 1.0 - this->damp;
        u0 = static_cast<int>(this->stLocLate);
        loc = accum_idx_0 + yClipperIn_idx_0 * p;
        accum_idx_0_tmp = a * loc + b_a * this->stLpf1[tmp_size_idx_0];
        this->stLpf1[tmp_size_idx_0] = accum_idx_0_tmp;
        trueCount = u0 + 153600 * tmp_size_idx_0;
        this->dLineLate[trueCount - 1] = (accum_idx_0_tmp * b + loc * b_b) *
          this->gLate[tmp_size_idx_0];
        loc = accum_idx_1 + yClipperIn_idx_1 * p;
        accum_idx_0_tmp = a * loc + b_a * this->stLpf1[tmp_size_idx_0 + 8];
        this->stLpf1[tmp_size_idx_0 + 8] = accum_idx_0_tmp;
        this->dLineLate[trueCount + 76799] = (accum_idx_0_tmp * b + loc * b_b) *
          this->gLate[tmp_size_idx_0 + 8];
        loc = (this->stLocLate - this->nLate[tmp_size_idx_0]) -
          nMod[tmp_size_idx_0];
        dv[0] = loc;
        trueCount = 0;
        if (loc < 1.0) {
          trueCount = 1;
        }

        if (0 <= trueCount - 1) {
          dv[0] = loc + 76800.0;
        }

        yLate_idx_0 += this->dLineLate[(static_cast<int>(dv[0]) + 153600 *
          tmp_size_idx_0) - 1] * this->outGain[tmp_size_idx_0];
        loc = (this->stLocLate - this->nLate[tmp_size_idx_0 + 8]) -
          nMod[tmp_size_idx_0];
        dv[0] = loc;
        trueCount = 0;
        if (loc < 1.0) {
          trueCount = 1;
        }

        if (0 <= trueCount - 1) {
          dv[0] = loc + 76800.0;
        }

        yLate_idx_1 += this->dLineLate[(static_cast<int>(dv[0]) + 153600 *
          tmp_size_idx_0) + 76799] * this->outGain[tmp_size_idx_0];
      }

      u0 = static_cast<int>(this->stLocLate);
      this->dLineLateDel[u0 - 1] = yLate_idx_0;
      this->dLineLateDel[u0 + 76799] = yLate_idx_1;
      loc = this->stLocLate - this->nLateDel;
      dv[0] = loc;
      trueCount = 0;
      if (loc < 1.0) {
        trueCount = 1;
      }

      if (0 <= trueCount - 1) {
        dv[0] = loc + 76800.0;
      }

      loc = this->dLineLateDel[static_cast<int>(dv[0]) - 1];
      loc = 1.5 * loc - 0.5 * rt_powd_snf(loc, 3.0);
      yClipperIn_idx_0 = loc;
      loc = this->dLineLateDel[static_cast<int>(dv[0]) + 76799];
      loc = 1.5 * loc - 0.5 * rt_powd_snf(loc, 3.0);
      if (this->serial) {
        b = this->aLate;
        yClipperIn_idx_0 *= b;
        yClipperIn_idx_1 = loc * b;
      } else {
        b = this->aLate;
        b_b = this->aEarly;
        yClipperIn_idx_0 = yClipperIn_idx_0 * b + yEarly_idx_0 * b_b;
        yClipperIn_idx_1 = loc * b + yEarly_idx_1 * b_b;
      }

      loc = 1.0 - this->mix;
      y[i] = loc * x[i] + this->mix * yClipperIn_idx_0;
      y[i + y.size(0)] = loc * x[i + x.size(0)] + this->mix * yClipperIn_idx_1;
    }

    this->stLocLate++;
    this->stLocEarly++;
    dv[0] = this->stLocLate;
    trueCount = 0;
    if (this->stLocLate > 76800.0) {
      trueCount = 1;
    }

    if (0 <= trueCount - 1) {
      dv[0] = 1.0;
    }

    this->stLocLate = dv[0];
    dv[0] = this->stLocEarly;
    trueCount = 0;
    if (this->stLocEarly > 153600.0) {
      trueCount = 1;
    }

    if (0 <= trueCount - 1) {
      dv[0] = 1.0;
    }

    this->stLocEarly = dv[0];
  }
}

void derivedAudioPlugin::reset()
{
  this->fs = this->getSampleRate();
  this->initDelay();
  std::memset(&this->dLineLate[0], 0, 1228800U * sizeof(double));
  this->update();
}

void derivedAudioPlugin::setSampleRateForReset(double rate)
{
  this->PrivateSampleRate = rate;
}

void derivedAudioPlugin::set_damp(double val)
{
  this->damp = val;
  this->update();
}

void derivedAudioPlugin::set_fLpf1(double val)
{
  this->fLpf1 = val;
  this->update();
}

void derivedAudioPlugin::set_gDiff_dB(double val)
{
  this->gDiff_dB = val;
  this->update();
}

void derivedAudioPlugin::set_gDriveIn_gui(double val)
{
  this->gDriveIn_gui = val;
  this->update();
}

void derivedAudioPlugin::set_gEarly_dB(double val)
{
  this->gEarly_dB = val;
  this->update();
}

void derivedAudioPlugin::set_mix_gui(double val)
{
  this->mix_gui = val;
  this->update();
}

void derivedAudioPlugin::set_modDepth_gui(double val)
{
  this->modDepth_gui = val;
  this->update();
}

void derivedAudioPlugin::set_modFreq(double val)
{
  this->modFreq = val;
  this->update();
}

void derivedAudioPlugin::set_t60(double val)
{
  this->t60 = val;
  this->update();
}

void derivedAudioPlugin::set_tLateDel(double val)
{
  this->tLateDel = val;
  this->update();
}

void derivedAudioPlugin::set_tPre(double val)
{
  this->tPre = val;
  this->update();
}

void derivedAudioPlugin::set_t_early_max(double val)
{
  this->t_early_max = val;
  this->initDelay();
}

void derivedAudioPlugin::set_t_early_min(double val)
{
  this->t_early_min = val;
  this->initDelay();
}

void derivedAudioPlugin::set_t_late_max(double val)
{
  this->t_late_max = val;
  this->initDelay();
}

void derivedAudioPlugin::set_t_late_min(double val)
{
  this->t_late_min = val;
  this->initDelay();
}

void derivedAudioPlugin::update()
{
  double y[8];
  double p;
  int k;
  p = this->t60 * this->fs;
  for (k = 0; k < 16; k++) {
    this->gLate[k] = rt_powd_snf(10.0, -3.0 * (this->nLate[k] / p)) /
      2.8284271247461903;
  }

  this->aLpf1 = 1.0 - std::exp(-6.2831853071795862 * this->fLpf1 / this->fs);
  this->aEarly = rt_powd_snf(10.0, this->gEarly_dB / 20.0);
  this->aLate = rt_powd_snf(10.0, this->gDiff_dB / 20.0);
  this->modDepth = this->modDepth_gui / 100.0;
  y[7] = 360.0;
  y[0] = 0.0;
  for (k = 0; k < 6; k++) {
    y[k + 1] = (static_cast<double>(k) + 1.0) * 51.428571428571431;
  }

  std::memcpy(&this->modPhase[0], &y[0], 8U * sizeof(double));
  y[7] = 0.0;
  y[0] = 360.0;
  for (k = 0; k < 6; k++) {
    y[k + 1] = (static_cast<double>(k) + 1.0) * -51.428571428571431 + 360.0;
  }

  std::memcpy(&this->modPhase[8], &y[0], 8U * sizeof(double));
  this->nLateDel = std::ceil(this->tLateDel * this->fs / 1000.0);
  this->mix = this->mix_gui / 100.0;
  this->nPre = std::ceil(this->tPre * this->fs / 1000.0);
  this->gDriveIn = rt_powd_snf(10.0, this->gDriveIn_gui / 20.0);
}

static void b_primesInRange(coder::array<double, 2U> &prim)
{
  static const signed char iv[17] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37,
    41, 43, 47, 53, 59 };

  coder::array<signed char, 2U> b_p_min2max;
  coder::array<signed char, 2U> p_min2max;
  int dist;
  int i1;
  int loop_ub;
  p_min2max.set_size(1, 1);
  p_min2max[0] = 0;
  for (dist = 0; dist < 17; dist++) {
    signed char i;
    i = iv[dist];
    if (i > 8) {
      i1 = p_min2max.size(1);
      p_min2max.set_size(p_min2max.size(0), (p_min2max.size(1) + 1));
      p_min2max[i1] = i;
    }
  }

  if (2 > p_min2max.size(1)) {
    i1 = 0;
    dist = 0;
  } else {
    i1 = 1;
    dist = p_min2max.size(1);
  }

  loop_ub = dist - i1;
  b_p_min2max.set_size(1, loop_ub);
  for (dist = 0; dist < loop_ub; dist++) {
    b_p_min2max[dist] = p_min2max[i1 + dist];
  }

  p_min2max.set_size(1, b_p_min2max.size(1));
  loop_ub = b_p_min2max.size(0) * b_p_min2max.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    p_min2max[i1] = b_p_min2max[i1];
  }

  dist = static_cast<int>(std::ceil(static_cast<double>(p_min2max.size(1)) / 8.0));
  if ((dist == 0) || ((dist > 0) && (1 > p_min2max.size(1)))) {
    dist = 1;
    i1 = -1;
  } else {
    i1 = p_min2max.size(1) - 1;
  }

  loop_ub = div_s32_floor(i1, dist);
  prim.set_size(1, (loop_ub + 1));
  for (i1 = 0; i1 <= loop_ub; i1++) {
    prim[i1] = p_min2max[dist * i1];
  }

  while (prim.size(1) < 8) {
    double n;
    n = prim[prim.size(1) - 1];
    do {
      n++;
    } while (!coder::isprime(n));

    i1 = prim.size(1);
    prim.set_size(prim.size(0), (prim.size(1) + 1));
    prim[i1] = n;

    //  disp("added");
  }

  while (prim.size(1) > 8) {
    prim.set_size(prim.size(0), (prim.size(1) - 1));

    //   disp("removed");
  }

  // disp("count = " + count + ", result = " + length(prim) + ", dist = " + dist); 
}

static void c_primesInRange(coder::array<double, 2U> &prim)
{
  static const signed char iv[25] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37,
    41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97 };

  coder::array<signed char, 2U> b_p_min2max;
  coder::array<signed char, 2U> p_min2max;
  int dist;
  int i1;
  int loop_ub;
  p_min2max.set_size(1, 1);
  p_min2max[0] = 0;
  for (dist = 0; dist < 25; dist++) {
    signed char i;
    i = iv[dist];
    if (i > 10) {
      i1 = p_min2max.size(1);
      p_min2max.set_size(p_min2max.size(0), (p_min2max.size(1) + 1));
      p_min2max[i1] = i;
    }
  }

  if (2 > p_min2max.size(1)) {
    i1 = 0;
    dist = 0;
  } else {
    i1 = 1;
    dist = p_min2max.size(1);
  }

  loop_ub = dist - i1;
  b_p_min2max.set_size(1, loop_ub);
  for (dist = 0; dist < loop_ub; dist++) {
    b_p_min2max[dist] = p_min2max[i1 + dist];
  }

  p_min2max.set_size(1, b_p_min2max.size(1));
  loop_ub = b_p_min2max.size(0) * b_p_min2max.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    p_min2max[i1] = b_p_min2max[i1];
  }

  dist = static_cast<int>(std::ceil(static_cast<double>(p_min2max.size(1)) / 8.0));
  if ((dist == 0) || ((dist > 0) && (1 > p_min2max.size(1)))) {
    dist = 1;
    i1 = -1;
  } else {
    i1 = p_min2max.size(1) - 1;
  }

  loop_ub = div_s32_floor(i1, dist);
  prim.set_size(1, (loop_ub + 1));
  for (i1 = 0; i1 <= loop_ub; i1++) {
    prim[i1] = p_min2max[dist * i1];
  }

  while (prim.size(1) < 8) {
    double n;
    n = prim[prim.size(1) - 1];
    do {
      n++;
    } while (!coder::isprime(n));

    i1 = prim.size(1);
    prim.set_size(prim.size(0), (prim.size(1) + 1));
    prim[i1] = n;

    //  disp("added");
  }

  while (prim.size(1) > 8) {
    prim.set_size(prim.size(0), (prim.size(1) - 1));

    //   disp("removed");
  }

  // disp("count = " + count + ", result = " + length(prim) + ", dist = " + dist); 
}

namespace coder
{
  static unsigned int intsqrt(unsigned int a)
  {
    unsigned int r;
    if (a <= 0U) {
      r = 0U;
    } else {
      unsigned int rhi;
      rhi = (a >> 1) + 1U;
      if (65535U < rhi) {
        rhi = 65535U;
      }

      if (a >= rhi * rhi) {
        r = rhi;
      } else {
        unsigned int rlo;
        boolean_T exitg1;
        rlo = 0U;
        r = rhi >> 1;
        exitg1 = false;
        while ((!exitg1) && (r > rlo)) {
          unsigned int rr;
          rr = r * r;
          if (rr == a) {
            exitg1 = true;
          } else {
            if (rr > a) {
              rhi = r;
            } else {
              rlo = r;
            }

            r = rlo + ((rhi - rlo) >> 1);
            if (r < rlo) {
              r = MAX_uint32_T;
            }
          }
        }
      }
    }

    return r;
  }

  static int intsqrt(int a)
  {
    int r;
    int rhi;
    rhi = a / 2 + 1;
    if (46340 < rhi) {
      rhi = 46340;
    }

    if (a >= rhi * rhi) {
      r = rhi;
    } else {
      int rlo;
      boolean_T exitg1;
      rlo = 0;
      r = rhi / 2;
      exitg1 = false;
      while ((!exitg1) && (r > rlo)) {
        int rr;
        rr = r * r;
        if (rr == a) {
          exitg1 = true;
        } else {
          if (rr > a) {
            rhi = r;
          } else {
            rlo = r;
          }

          rr = (rhi - rlo) / 2;
          if ((rlo < 0) && (rr < MIN_int32_T - rlo)) {
            r = MIN_int32_T;
          } else if ((rlo > 0) && (rr > MAX_int32_T - rlo)) {
            r = MAX_int32_T;
          } else {
            r = rlo + rr;
          }
        }
      }
    }

    return r;
  }

  static boolean_T isprime(double X)
  {
    array<int, 2U> p;
    array<boolean_T, 2U> b_isp;
    double n;
    double rtmp;
    int i;
    int j;
    int k;
    boolean_T isp;
    n = 0.0;
    if (X > 0.0) {
      n = X;
    }

    rtmp = std::floor(std::sqrt(n));
    if (rtmp * rtmp > n) {
      n = rtmp - 1.0;
    } else {
      n = rtmp;
    }

    if (n < 2.147483648E+9) {
      i = static_cast<int>(n);
    } else {
      i = MAX_int32_T;
    }

    if (i < 2) {
      p.set_size(1, 0);
    } else if (i < 3) {
      p.set_size(1, 1);
      p[0] = 2;
    } else {
      int kmax;
      int nleft;
      int np;
      unsigned int q;
      q = static_cast<unsigned int>(i) >> 1;
      if (i - (q << 1) > 0U) {
        q++;
      }

      np = static_cast<int>(q);
      b_isp.set_size(1, (static_cast<int>(q)));
      kmax = static_cast<int>(q);
      for (nleft = 0; nleft < kmax; nleft++) {
        b_isp[nleft] = true;
      }

      kmax = intsqrt(i);
      k = 3;
      nleft = static_cast<int>(q);
      while (k <= kmax) {
        if (b_isp[(k + 1) / 2 - 1]) {
          i = (k * k + 1) / 2;
          for (j = i; k < 0 ? j >= np : j <= np; j += k) {
            if (b_isp[j - 1]) {
              b_isp[j - 1] = false;
              nleft--;
            }
          }
        }

        k += 2;
      }

      p.set_size(1, nleft);
      kmax = 1;
      p[0] = 2;
      for (k = 2; k <= np; k++) {
        if (b_isp[k - 1] && (kmax < 6605207)) {
          kmax++;
          p[kmax - 1] = (k << 1) - 1;
        }
      }
    }

    if (X < 2.0) {
      isp = false;
    } else {
      boolean_T exitg1;
      isp = true;
      j = 0;
      exitg1 = false;
      while ((!exitg1) && (j <= p.size(1) - 1)) {
        i = p[j];
        if (X <= i) {
          exitg1 = true;
        } else if (rt_remd_snf(X, static_cast<double>(i)) == 0.0) {
          isp = false;
          exitg1 = true;
        } else {
          j++;
        }
      }
    }

    return isp;
  }

  static void primes(double n, ::coder::array<double, 2U> &p)
  {
    array<boolean_T, 2U> isp;
    unsigned int j;
    unsigned int k;
    if (n < 2.0) {
      p.set_size(1, 0);
    } else if (n < 3.0) {
      p.set_size(1, 1);
      p[0] = 2.0;
    } else {
      double d;
      unsigned int kmax;
      int loop_ub;
      unsigned int m;
      unsigned int nleft;
      unsigned int np;
      d = std::floor(n);
      if (d < 4.294967296E+9) {
        m = static_cast<unsigned int>(d);
      } else if (d >= 4.294967296E+9) {
        m = MAX_uint32_T;
      } else {
        m = 0U;
      }

      np = m >> 1;
      if (m - (np << 1) > 0U) {
        np++;
      }

      isp.set_size(1, (static_cast<int>(np)));
      loop_ub = static_cast<int>(np);
      for (int i = 0; i < loop_ub; i++) {
        isp[i] = true;
      }

      kmax = intsqrt(m);
      k = 3U;
      nleft = np;
      while (k <= kmax) {
        if (isp[static_cast<int>((k + 1U) >> 1) - 1]) {
          m = (k * k + 1U) >> 1;
          for (j = m; j <= np; j += k) {
            if (isp[static_cast<int>(j) - 1]) {
              isp[static_cast<int>(j) - 1] = false;
              nleft--;
            }
          }
        }

        k += 2U;
      }

      p.set_size(1, (static_cast<int>(nleft)));
      m = 1U;
      p[0] = 2.0;
      for (k = 2U; k <= np; k++) {
        if (isp[static_cast<int>(k) - 1] && (m < 203280221U)) {
          m++;
          p[static_cast<int>(m) - 1] = (k << 1) - 1U;
        }
      }
    }
  }
}

static void d_primesInRange(coder::array<double, 2U> &prim)
{
  static const signed char iv[29] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37,
    41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109 };

  coder::array<signed char, 2U> b_p_min2max;
  coder::array<signed char, 2U> p_min2max;
  int dist;
  int i1;
  int loop_ub;
  p_min2max.set_size(1, 1);
  p_min2max[0] = 0;
  for (dist = 0; dist < 29; dist++) {
    signed char i;
    i = iv[dist];
    if (i > 4) {
      i1 = p_min2max.size(1);
      p_min2max.set_size(p_min2max.size(0), (p_min2max.size(1) + 1));
      p_min2max[i1] = i;
    }
  }

  if (2 > p_min2max.size(1)) {
    i1 = 0;
    dist = 0;
  } else {
    i1 = 1;
    dist = p_min2max.size(1);
  }

  loop_ub = dist - i1;
  b_p_min2max.set_size(1, loop_ub);
  for (dist = 0; dist < loop_ub; dist++) {
    b_p_min2max[dist] = p_min2max[i1 + dist];
  }

  p_min2max.set_size(1, b_p_min2max.size(1));
  loop_ub = b_p_min2max.size(0) * b_p_min2max.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    p_min2max[i1] = b_p_min2max[i1];
  }

  dist = static_cast<int>(std::ceil(static_cast<double>(p_min2max.size(1)) / 8.0));
  if ((dist == 0) || ((dist > 0) && (1 > p_min2max.size(1)))) {
    dist = 1;
    i1 = -1;
  } else {
    i1 = p_min2max.size(1) - 1;
  }

  loop_ub = div_s32_floor(i1, dist);
  prim.set_size(1, (loop_ub + 1));
  for (i1 = 0; i1 <= loop_ub; i1++) {
    prim[i1] = p_min2max[dist * i1];
  }

  while (prim.size(1) < 8) {
    double n;
    n = prim[prim.size(1) - 1];
    do {
      n++;
    } while (!coder::isprime(n));

    i1 = prim.size(1);
    prim.set_size(prim.size(0), (prim.size(1) + 1));
    prim[i1] = n;

    //  disp("added");
  }

  while (prim.size(1) > 8) {
    prim.set_size(prim.size(0), (prim.size(1) - 1));

    //   disp("removed");
  }

  // disp("count = " + count + ", result = " + length(prim) + ", dist = " + dist); 
}

static int div_s32_floor(int numerator, int denominator)
{
  unsigned int absNumerator;
  int quotient;
  if (denominator == 0) {
    if (numerator >= 0) {
      quotient = MAX_int32_T;
    } else {
      quotient = MIN_int32_T;
    }
  } else {
    unsigned int absDenominator;
    unsigned int tempAbsQuotient;
    boolean_T quotientNeedsNegation;
    if (numerator < 0) {
      absNumerator = ~static_cast<unsigned int>(numerator) + 1U;
    } else {
      absNumerator = static_cast<unsigned int>(numerator);
    }

    if (denominator < 0) {
      absDenominator = ~static_cast<unsigned int>(denominator) + 1U;
    } else {
      absDenominator = static_cast<unsigned int>(denominator);
    }

    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    tempAbsQuotient = absNumerator / absDenominator;
    if (quotientNeedsNegation) {
      absNumerator %= absDenominator;
      if (absNumerator > 0U) {
        tempAbsQuotient++;
      }

      quotient = -static_cast<int>(tempAbsQuotient);
    } else {
      quotient = static_cast<int>(tempAbsQuotient);
    }
  }

  return quotient;
}

static derivedAudioPlugin *getPluginInstance(ntRev3StackData *SD)
{
  if (!SD->pd->plugin_not_empty) {
    SD->pd->plugin.init(SD);
    SD->pd->plugin_not_empty = true;
  }

  return &SD->pd->plugin;
}

static void getPluginInstance_init(ntRev3StackData *SD)
{
  SD->pd->plugin_not_empty = false;
}

static void primesInRange(coder::array<double, 2U> &prim)
{
  static const signed char iv[19] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37,
    41, 43, 47, 53, 59, 61, 67 };

  coder::array<signed char, 2U> b_p_min2max;
  coder::array<signed char, 2U> p_min2max;
  int dist;
  int i1;
  int loop_ub;
  p_min2max.set_size(1, 1);
  p_min2max[0] = 0;
  for (dist = 0; dist < 19; dist++) {
    signed char i;
    i = iv[dist];
    if (i > 6) {
      i1 = p_min2max.size(1);
      p_min2max.set_size(p_min2max.size(0), (p_min2max.size(1) + 1));
      p_min2max[i1] = i;
    }
  }

  if (2 > p_min2max.size(1)) {
    i1 = 0;
    dist = 0;
  } else {
    i1 = 1;
    dist = p_min2max.size(1);
  }

  loop_ub = dist - i1;
  b_p_min2max.set_size(1, loop_ub);
  for (dist = 0; dist < loop_ub; dist++) {
    b_p_min2max[dist] = p_min2max[i1 + dist];
  }

  p_min2max.set_size(1, b_p_min2max.size(1));
  loop_ub = b_p_min2max.size(0) * b_p_min2max.size(1);
  for (i1 = 0; i1 < loop_ub; i1++) {
    p_min2max[i1] = b_p_min2max[i1];
  }

  dist = static_cast<int>(std::ceil(static_cast<double>(p_min2max.size(1)) / 8.0));
  if ((dist == 0) || ((dist > 0) && (1 > p_min2max.size(1)))) {
    dist = 1;
    i1 = -1;
  } else {
    i1 = p_min2max.size(1) - 1;
  }

  loop_ub = div_s32_floor(i1, dist);
  prim.set_size(1, (loop_ub + 1));
  for (i1 = 0; i1 <= loop_ub; i1++) {
    prim[i1] = p_min2max[dist * i1];
  }

  while (prim.size(1) < 8) {
    double n;
    n = prim[prim.size(1) - 1];
    do {
      n++;
    } while (!coder::isprime(n));

    i1 = prim.size(1);
    prim.set_size(prim.size(0), (prim.size(1) + 1));
    prim[i1] = n;

    //  disp("added");
  }

  while (prim.size(1) > 8) {
    prim.set_size(prim.size(0), (prim.size(1) - 1));

    //   disp("removed");
  }

  // disp("count = " + count + ", result = " + length(prim) + ", dist = " + dist); 
}

static void primesInRange(double b_min, double b_max, coder::array<double, 2U>
  &prim)
{
  coder::array<double, 2U> p_all;
  coder::array<double, 2U> p_min2max;
  double n;
  int dist;
  int i;
  int i1;
  int loop_ub;
  coder::primes(b_max, p_all);
  p_min2max.set_size(1, 1);
  p_min2max[0] = 0.0;
  i = p_all.size(1);
  for (dist = 0; dist < i; dist++) {
    n = p_all[dist];
    if (n > b_min) {
      i1 = p_min2max.size(1);
      p_min2max.set_size(p_min2max.size(0), (p_min2max.size(1) + 1));
      p_min2max[i1] = n;
    }
  }

  if (2 > p_min2max.size(1)) {
    i = 0;
    i1 = 0;
  } else {
    i = 1;
    i1 = p_min2max.size(1);
  }

  loop_ub = i1 - i;
  p_all.set_size(1, loop_ub);
  for (i1 = 0; i1 < loop_ub; i1++) {
    p_all[i1] = p_min2max[i + i1];
  }

  p_min2max.set_size(1, p_all.size(1));
  loop_ub = p_all.size(0) * p_all.size(1);
  for (i = 0; i < loop_ub; i++) {
    p_min2max[i] = p_all[i];
  }

  dist = static_cast<int>(std::ceil(static_cast<double>(p_min2max.size(1)) / 8.0));
  if ((dist == 0) || ((dist > 0) && (1 > p_min2max.size(1)))) {
    dist = 1;
    i = -1;
  } else {
    i = p_min2max.size(1) - 1;
  }

  loop_ub = div_s32_floor(i, dist);
  prim.set_size(1, (loop_ub + 1));
  for (i = 0; i <= loop_ub; i++) {
    prim[i] = p_min2max[dist * i];
  }

  while (prim.size(1) < 8) {
    n = prim[prim.size(1) - 1];
    do {
      n++;
    } while (!coder::isprime(n));

    i = prim.size(1);
    prim.set_size(prim.size(0), (prim.size(1) + 1));
    prim[i] = n;

    //  disp("added");
  }

  while (prim.size(1) > 8) {
    prim.set_size(prim.size(0), (prim.size(1) - 1));

    //   disp("removed");
  }

  // disp("count = " + count + ", result = " + length(prim) + ", dist = " + dist); 
}

static double rt_powd_snf(double u0, double u1)
{
  double y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else {
    double d;
    double d1;
    d = std::abs(u0);
    d1 = std::abs(u1);
    if (rtIsInf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = rtNaN;
    } else {
      y = std::pow(u0, u1);
    }
  }

  return y;
}

static double rt_remd_snf(double u0, double u1)
{
  double y;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = rtNaN;
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    double b_u1;
    if (u1 < 0.0) {
      b_u1 = std::ceil(u1);
    } else {
      b_u1 = std::floor(u1);
    }

    if ((u1 != 0.0) && (u1 != b_u1)) {
      b_u1 = std::abs(u0 / u1);
      if (!(std::abs(b_u1 - std::floor(b_u1 + 0.5)) > DBL_EPSILON * b_u1)) {
        y = 0.0 * u0;
      } else {
        y = std::fmod(u0, u1);
      }
    } else {
      y = std::fmod(u0, u1);
    }
  }

  return y;
}

static double rt_roundd_snf(double u)
{
  double y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

derivedAudioPlugin::~derivedAudioPlugin()
{
}

derivedAudioPlugin::derivedAudioPlugin()
{
}

void createPluginInstance(ntRev3StackData *SD, unsigned long thisPtr)
{
  if (!SD->pd->thisPtr_not_empty) {
    SD->pd->thisPtr = thisPtr;
    SD->pd->thisPtr_not_empty = true;
  }

  getPluginInstance(SD);
}

int getLatencyInSamplesCImpl(ntRev3StackData *SD)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  return plugin->getLatencyInSamplesInt32();
}

void ntRev3_initialize(ntRev3StackData *SD)
{
  SD->pd->thisPtr_not_empty = false;
  getPluginInstance_init(SD);
}

void ntRev3_terminate()
{
  // (no terminate code required)
}

void onParamChangeCImpl(ntRev3StackData *SD, int paramIdx, double value)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  switch (paramIdx) {
   case 0:
    plugin->set_t60(value);
    break;

   case 1:
    plugin->set_tPre(value);
    break;

   case 2:
    plugin->set_tLateDel(value);
    break;

   case 3:
    plugin->set_fLpf1(value);
    break;

   case 4:
    plugin->set_damp(value);
    break;

   case 5:
    plugin->set_gDriveIn_gui(value);
    break;

   case 6:
    plugin->set_gEarly_dB(value);
    break;

   case 7:
    plugin->set_gDiff_dB(value);
    break;

   case 8:
    plugin->set_mix_gui(value);
    break;

   case 9:
    plugin->set_modFreq(value);
    break;

   case 10:
    plugin->set_modDepth_gui(value);
    break;

   case 11:
    plugin->set_t_early_min(value);
    break;

   case 12:
    plugin->set_t_early_max(value);
    break;

   case 13:
    plugin->set_t_late_min(value);
    break;

   case 14:
    plugin->set_t_late_max(value);
    break;

   case 15:
    plugin->bypass = (value != 0.0);
    break;
  }
}

void processEntryPoint(ntRev3StackData *SD, double samplesPerFrame, const double
  i1_data[], const int i1_size[1], const double i2_data[], const int i2_size[1],
  double o1_data[], int o1_size[1], double o2_data[], int o2_size[1])
{
  derivedAudioPlugin *plugin;
  coder::array<double, 2U> i1;
  coder::array<double, 2U> t1;
  int i;
  int loop_ub;
  plugin = getPluginInstance(SD);
  i1.set_size(i1_size[0], 2);
  loop_ub = i1_size[0];
  for (i = 0; i < loop_ub; i++) {
    i1[i] = i1_data[i];
  }

  loop_ub = i2_size[0];
  for (i = 0; i < loop_ub; i++) {
    i1[i + i1.size(0)] = i2_data[i];
  }

  plugin->process(i1, t1);
  if (1.0 > samplesPerFrame) {
    loop_ub = 0;
  } else {
    loop_ub = static_cast<int>(samplesPerFrame);
  }

  o1_size[0] = loop_ub;
  for (i = 0; i < loop_ub; i++) {
    o1_data[i] = t1[i];
  }

  if (1.0 > samplesPerFrame) {
    loop_ub = 0;
  } else {
    loop_ub = static_cast<int>(samplesPerFrame);
  }

  o2_size[0] = loop_ub;
  for (i = 0; i < loop_ub; i++) {
    o2_data[i] = t1[i + t1.size(0)];
  }
}

void resetCImpl(ntRev3StackData *SD, double rate)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  plugin->setSampleRateForReset(rate);
  plugin->reset();
}

// End of code generation (ntRev3.cpp)
