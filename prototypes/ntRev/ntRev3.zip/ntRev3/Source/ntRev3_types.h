//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  ntRev3_types.h
//
//  Code generation for function 'onParamChangeCImpl'
//


#ifndef NTREV3_TYPES_H
#define NTREV3_TYPES_H

// Include files
#include "ntRev3.h"
#include "rtwtypes.h"

// Type Definitions
struct ntRev3PersistentData
{
  derivedAudioPlugin plugin;
  boolean_T plugin_not_empty;
  unsigned long thisPtr;
  boolean_T thisPtr_not_empty;
};

struct ntRev3StackData
{
  ntRev3PersistentData *pd;
};

#endif

// End of code generation (ntRev3_types.h)
