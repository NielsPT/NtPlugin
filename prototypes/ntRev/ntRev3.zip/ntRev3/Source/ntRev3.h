//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  ntRev3.h
//
//  Code generation for function 'ntRev3'
//


#ifndef NTREV3_H
#define NTREV3_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct ntRev3StackData;

// Type Definitions
class derivedAudioPlugin
{
 public:
  derivedAudioPlugin *init(ntRev3StackData *SD);
  void set_t60(double val);
  void update();
  void set_tPre(double val);
  void set_tLateDel(double val);
  void set_fLpf1(double val);
  void set_damp(double val);
  void set_gDriveIn_gui(double val);
  void set_gEarly_dB(double val);
  void set_gDiff_dB(double val);
  void set_mix_gui(double val);
  void set_modFreq(double val);
  void set_modDepth_gui(double val);
  void set_t_early_min(double val);
  void initDelay();
  void set_t_early_max(double val);
  void set_t_late_min(double val);
  void set_t_late_max(double val);
  void setSampleRateForReset(double rate);
  void reset();
  double getSampleRate() const;
  void process(coder::array<double, 2U> &x, coder::array<double, 2U> &y);
  int getLatencyInSamplesInt32() const;
  derivedAudioPlugin();
  ~derivedAudioPlugin();
  double fs;
  double tPre;
  double nPre;
  double t60;
  double mix_gui;
  double gEarly_dB;
  double gDiff_dB;
  double fLpf1;
  double damp;
  double tLateDel;
  double mix;
  boolean_T serial;
  boolean_T bypass;
  double method;
  double t_early_min;
  double t_early_max;
  double t_late_min;
  double t_late_max;
  double modFreq;
  double modPhase[16];
  double modDepth_gui;
  double modDepth;
  double gDriveIn_gui;
  double gDriveOut_gui;
  double gDriveIn;
  double dLineEarly[307200];
  double dLineLate[1228800];
  double dLineLateDel[153600];
  double nEarly[16];
  double nLate[16];
  double nLateDel;
  double gEarly[16];
  double stLocLate;
  double stLocEarly;
  double gLate[16];
  double Q[64];
  double inGain[8];
  double outGain[8];
  double stLpf1[16];
  double aLpf1;
  double aEarly;
  double aLate;
  double infTime;
 protected:
  int PrivateLatency;
 private:
  double PrivateSampleRate;
};

// Function Declarations
extern void createPluginInstance(ntRev3StackData *SD, unsigned long thisPtr);
extern int getLatencyInSamplesCImpl(ntRev3StackData *SD);
extern void ntRev3_initialize(ntRev3StackData *SD);
extern void ntRev3_terminate();
extern void onParamChangeCImpl(ntRev3StackData *SD, int paramIdx, double value);
extern void processEntryPoint(ntRev3StackData *SD, double samplesPerFrame, const
  double i1_data[], const int i1_size[1], const double i2_data[], const int
  i2_size[1], double o1_data[], int o1_size[1], double o2_data[], int o2_size[1]);
extern void resetCImpl(ntRev3StackData *SD, double rate);

#endif

// End of code generation (ntRev3.h)
